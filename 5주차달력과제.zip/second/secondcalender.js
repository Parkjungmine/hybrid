var yearSelector = document.querySelector('.yearSelector');
var monthSelector = document.querySelector('.monthSelector');


var monthNames = ['January', 'Feburary', 'March', 'April', 'May',
'June', 'July', 'August', 'September', 'October',
'November', 'December'];


for(var i=1969; i<= 2018; i++){
  var option = document.createElement('option');
  option.value = i;
  option.innerHTML = 1;
  yearSelector.appendChild(option);
}
for(var i=0; i<12; i++){
  var option = document.createElement('option');
  option.value = i;
  option.innerHTML = monthNames [i];
  monthSelector.appendChild(option);
}


var btn = document.querySelector('.calendarButton');

btn.onclick= function(){

  var tbl = document.querySelector('table');
  if(tbl) {
    tbl.parentNode.removeChild (tbl);
  }

  var yearSelector = document.querySelector('.yearSelector');
  var monthSelector = document.querySelector('.monthSelector');
  var monthNames = ['January', 'Feburary', 'March', 'April', 'May',
    'June', 'July', 'August', 'September', 'October',
    'November', 'December'];
var selectedYear =yearSelector.value;
var selectedMonth= monthSelector.value;
var firstDateTex = selectedYear + '-' + (Number(selectedMonth) + 1) + 1;
var firstDateObj = new Date(firstDateText);
var firstWeekDay = firstDateObj.getDay();
var daysInMonth;
var testMonth = Number (selected Month) + 1;
switch(testMonth) {
  case 1:
  case 3:
  case 5:
  case 7:
  case 8:
  case 10:
  case 12:
    daysInMonth = 31;
    break;
  case 4:
  case 6:
  case 9:
  case 11:
      daysInMonth = 30;
      break;
  case 2:
      daysInMonth = 28;
      break;
  default:
    daysInMonth = 30;
    break;
}
