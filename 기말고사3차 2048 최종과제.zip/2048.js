const Num = document.querySelectorAll(`.Num`); // Num 넘겨받는다
const startGameBtn = document.querySelector('#startGameBtn'); //게임스타트버튼
const Restart = document.querySelector('#Restart');
let NumLength = Num.length; // Num의 길이말하는것
let board=new Array(6); // 배열 정해줌
const scoreText = document.querySelector('#score'); // 스코어 처리해줄떄 필요한 것

let score = 0; // 스코어 초기화

let overCheck = 1; //게임오버 인지 체크해주기 위한 것
let numCheck = 1; //이동할떄마다 숫자체크해주기 위함

for(let i=0;i<6;i++){
    board[i]=new Array(6);
}
// i = 0 ~ i = 5가 될떄까지의 배열

for(let i = 0; i < 6; i++) { // i = 0 ~ i = 5가 될떄까지의 배열
    for(let j = 0; j < 6; j++) {
        if(i == 0 || j == 0 || i == 5 || j == 5) {
            board[i][j] = 1;
            // 만일 0이나 5의 경우라면 1로 처리한다
            //이유는 1 ~ 4칸까지의 가로 세로로 이어져있기 떄문에
            //필요없는 0과 5를 잘라준것.
        }
    }
}

console.log(board);
init();

// GAME START 시작 지정 함수
function init() {
    for(let i = 1; i < 5; i++) {
        // i가 1 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 4까지 해준다.
        for(let j = 1; j < 5; j++) {
            // i가 1 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 4까지 해준다.
            board[i][j] = 0;
        }
    }
    randomNum();
    // 게임 시작할때 랜덤한 숫자를 넣어주기 위해 넣어주었다.
    // 다만 게임 시작할떄 2,2나 4,4가 있으면 안되기떄문에 2를 확정으로넣어줌
    // 단 위치는 랜덤
    randomNum2();
    // 게임 시작할때 2,2나 4,4가 있으면 안되기떄문에 2번을따로 만들어 4를 넣어줌.
    // 단 위치는 랜덤
    update();
    // 업데이트 시작
}


// 업데이트, 여기서 바꿔줌.
function update() {  
    let cnt = 0;
    for(let i = 1; i < 5; i++) {
        // i가 1 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 4까지 해준다.
        for(let j = 1; j < 5; j++) {
            Num[cnt].innerHTML = board[i][j] == 0 ? "" : board[i][j];
            // 여기서 숫자 [cnt]를 박스안에 넣어주는 것.
            coloring(cnt);
            // 색을 아래있는 colorring을 숫자에 맞춰서 해주는 것이다.
            cnt++;
            // cnt 숫자를 올려준다.
        }
    }
}

// 스코어 해주는것
function setScore() {
    scoreText.innerHTML = "MoveCount : " + score;
    // scoreText.innerHTML 에 움직일때마다 + score 넣어줌.
}


// 색변경
function coloring(cnt) { 
    Num[cnt].style.border = "solid black 1px";
    // 외곽선 일반적인 라인 테두리에 검은색 1px로 준다는 의미.
    switch(Num[cnt].innerHTML) {
        case "2":
            Num[cnt].style.backgroundColor = "#BFBFFF";
            // Num이 2일때 색 넣어주기
            break;
        case "4":
            Num[cnt].style.backgroundColor = "#9999CC";
            // Num이 4일때 색 넣어주기
            break;
        case "8":
            Num[cnt].style.backgroundColor = "#737399";
            // Num이 8일때 색 넣어주기
            break;    
        case "16":
            Num[cnt].style.backgroundColor = "#8080FF";
            // Num이 16일때 색 넣어주기
            break;
        case "32":
            Num[cnt].style.backgroundColor = "#6666CC";
            // Num이 32일때 색 넣어주기
            break;
        case "64":
            Num[cnt].style.backgroundColor = "#4D4C99";
            // Num이 64일때 색 넣어주기
            break;
        case "128":
            Num[cnt].style.backgroundColor = "#4040FF";
            // Num이 128일때 색 넣어주기
            break;
        case "256":
            Num[cnt].style.backgroundColor = "#3333CC";
            // Num이 256일때 색 넣어주기
            break;
        case "512":
            Num[cnt].style.backgroundColor = "#262699";
            // Num이 512일때 색 넣어주기
            break;
        case "1024":
            Num[cnt].style.backgroundColor = "#0000FF";
            // Num이 1024일때 색 넣어주기
            break;
        case "2048":
            Num[cnt].style.backgroundColor = "#000099";
            // Num이 2048일때 색 넣어주기
            break;
        default:
            if(Num.innerHTML > 2048) {
                Num[cnt].style.backgroundColor = "#7d5fff";
                // 2048보다 숫자가 높아지면 넣어주기
            }
            else {
                Num[cnt].style.backgroundColor = "#808e9b";
                // 숫자가 없을때 div 색상
            }    
    }
}
// 랜덤한곳에 넣어주기 위한 함수
function randomNum() {
    ranPlaceX = Math.floor(Math.random() * 4 + 1);
    // 랜덤한곳에 x축의, 즉 가로 4칸중에 랜덤한 장소에 넣어준다는 의미.
    ranPlaceY = Math.floor(Math.random() * 4 + 1);
    // 랜덤한곳에 y축의, 즉 세로 4칸중에 랜덤한 장소에 넣어준다는 의미.
    if(board[ranPlaceX][ranPlaceY] == 0) {
        board[ranPlaceX][ranPlaceY] = 2;
        // 아무것도 없을떄 2넣어준다.
    }
    else {
        randomNum();
        // 위에 해당하지 않으면 randomNum()실시
    }
    update();
    // 업데이트 적용
}
// 시작할떄 4를 넣어주기 위한 함수
function randomNum2() {
    ranPlaceX = Math.floor(Math.random() * 4 + 1);
    // 랜덤한곳에 x축의, 즉 가로 4칸중에 랜덤한 장소에 넣어준다는 의미.
    ranPlaceY = Math.floor(Math.random() * 4 + 1);
    // 랜덤한곳에 y축의, 즉 세로 4칸중에 랜덤한 장소에 넣어준다는 의미.
    if(board[ranPlaceX][ranPlaceY] == 0) {
        board[ranPlaceX][ranPlaceY] = 4;
        // 아무것도 없을떄 4넣어준다.
    }
    else {
        randomNum();
        // 위에 해당하지 않으면 randomNum()실시
    }
}
// 왼쪽으로 이동했을떄 숫자 계산
function moveLeftNum() {
    let k;

    numCheck = 1
    // 숫자계산 시작

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            // i, j가 1 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 4까지 해준다.
            if(board[i][j] != 0) {
                k = j;
                // 입력 받아주고 값 넣어줬을떄
                while(1) {
                    if(board[i][k-1] != 0) {
                        // 맞는 값이 나오면 반복문을 멈춰준다.
                        break;
                    }
                    board[i][k-1] = board[i][k];
                    board[i][k] = 0;
                    k--;
                    numCheck = 0;
                    // 이곳에서 시각적으로 보이도록 숫자 넣어줌, 숫자 계산 종료.
                }
            }
        }
    }
}
// 왼쪽으로 이동했을 때
function moveLeft() {
    gameOver();
    moveLeftNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            // j가 1 이기 떄문에 1 ~ 4칸까지이지만 맨 오른쪽이 4번째 칸이기 때문에
            // 3번쨰까지만있으면 되기 떄문에 j < 4를 넣어줌.
            if(board[i][j] == board[i][j+1] && board[i][j] != 0) {
                numCheck = 0;
                board[i][j] *= 2;
                board[i][j+1] = 0;
                // 왼쪽으로 이동해주었다는 것에대한 시각적으로 이동
            }
        }
    }
    if(!numCheck) {
        moveLeftNum();
        randomNum();
        update();
        // numCheck가 false라면 다시 입력값 받고 새로 생성해주고 업데이트
    }
}
// 위쪽으로 이동했을 때 숫자 계산
function moveUpNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            // i, j가 1 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 4까지 해준다.
            if(board[j][i] != 0) {
                k = j;
                // 입력 받아주고 값 넣어줬을떄
                while(1) {
                    if(board[k-1][i] != 0) {
                        // 맞는 값이 나오면 반복문을 멈춰준다.
                        break;
                    }
                    board[k-1][i] = board[k][i];
                    board[k][i] = 0;
                    k--;
                    numCheck = 0;
                    // 이곳에서 시각적으로 보이도록 숫자 넣어줌, 숫자 계산 종료.
                }
            }
        }
    }
}
// 위쪽으로 이동했을 때
function moveUp() {
    gameOver();
    moveUpNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            // j가 1 이기 떄문에 1 ~ 4칸까지이지만 맨 아래쪽이 4번째 칸이기 때문에
            // 3번쨰까지만있으면 되기 떄문에 j < 4를 넣어줌.
            if(board[j][i] == board[j+1][i] && board[j][i] != 0) {
                board[j][i] *= 2;
                board[j+1][i] = 0;
                numCheck = 0;
                // 위쪽으로 이동해주었다는 것에대한 시각적으로 이동
            }
        }
    }
    if(!numCheck) {
        moveUpNum();
        randomNum();
        update();
        // numCheck가 false라면 다시 입력값 받고 새로 생성해주고 업데이트
    }
}
// 오른쪽으로 이동했을 때 숫자 계산
function moveRightNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 0; j--) {
            // j가 4 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 1까지 해준다.
            if(board[i][j] != 0) {
                k = j;
                // 입력 받아주고 값 넣어줬을떄
                while(1) {
                    if(board[i][k+1] != 0) {
                        // 맞는 값이 나오면 반복문을 멈춰준다.
                        break;
                    }
                    board[i][k+1] = board[i][k];
                    board[i][k] = 0;
                    k++;
                    numCheck = 0;
                    // 이곳에서 시각적으로 보이도록 숫자 넣어줌, 숫자 계산 종료.
                }
            }
        }
    }
}
// 오른쪽으로 이동했을 때
function moveRight() {
    gameOver();
    moveRightNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j >1; j--) {
            // j가 4 이기 떄문에 1 ~ 4칸까지이지만 맨 왼쪽이 1번째 칸이기 때문에
            // 3번쨰까지만있으면 되기 떄문에 j > 1을 넣어줌.
            if(board[i][j] == board[i][j-1] && board[i][j] != 0) {
                board[i][j] *= 2;
                board[i][j-1] = 0;
                numCheck = 0;
                // 오른쪽으로 이동해주었다는 것에대한 시각적으로 이동
            }
        }
    }
    if(!numCheck) {
        moveRightNum();
        randomNum();
        update();
        // numCheck가 false라면 다시 입력값 받고 새로 생성해주고 업데이트
    }
}
// 아래쪽으로 이동했을 때 숫자 계산
function moveDownNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 0; j--) {
            // j가 4 이기 떄문에 1 ~ 4칸까지의 크기에 맞추기 위해 1까지 해준다.
            if(board[j][i] != 0) {
                k = j;
                // 입력 받아주고 값 넣어줬을떄
                while(1) {
                    if(board[k+1][i] != 0) {
                        // 맞는 값이 나오면 반복문을 멈춰준다.
                        break;
                    }
                    board[k+1][i] = board[k][i];
                    board[k][i] = 0;
                    k++; 
                    numCheck = 0;
                    // 이곳에서 시각적으로 보이도록 숫자 넣어줌, 숫자 계산 종료.
                }
            }
        }
    }
}
// 아래쪽으로 이동했을 때
function moveDown(){
    gameOver();
    moveDownNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 1; j--) {
            // j가 4 이기 떄문에 1 ~ 4칸까지이지만 맨 위쪽이 1번째 칸이기 때문에
            // 3번쨰까지만있으면 되기 떄문에 j > 1을 넣어줌.
            if(board[j][i] == board[j-1][i] && board[j][i] != 0) {
                board[j][i] *= 2;
                board[j-1][i] = 0;
                numCheck = 0;
                // 오른쪽으로 이동해주었다는 것에대한 시각적으로 이동
            }
        }
    }
    if(!numCheck) {     
        moveDownNum();
        randomNum();
        update();
        // numCheck가 false라면 다시 입력값 받고 새로 생성해주고 업데이트
    }
}

function rowCheck() {
    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[i][j] == board[i][j+1]) {
                overCheck = 0;
                // 세로에 더이상 넣을수 있는 곳이 없다면 받아주지 않는다는 것.
            }
        }
    }
}

function columnCheck() { 
    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[j][i] == board[j+1][i]) {
                overCheck = 0;
                // 가로에 더이상 넣을수 있는 곳이 없다면 받아주지 않는다는 것.
            }
        }
    }
}

//게임끝나는것
function gameOver() {
    let fullCheck = 1; // 모든 곳에 다 숫자가 가득찰때

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            if(board[i][j] == 0) {
                fullCheck = 0; // 초기화
            }
        }
    }
    rowCheck();
    // 세로에 더이상 넣을수 있는 곳이 없다면 받아주지 않는다는 것.
    columnCheck();
    // 가로에 더이상 넣을수 있는 곳이 없다면 받아주지 않는다는 것.
    if(fullCheck && overCheck) { // 게임 끝났는지 체크
        window.location.reload(); // 화면을 다시 처음화면으로 돌린다.
    }

    overCheck = 1; // 다시 시작한다
}

//방향키 먹여주는것
window.addEventListener("keydown", (e)=> {
    const keyCode = e.keyCode;
    if(keyCode == 37) {
        moveLeft();
        score += 1
        // 키보드 왼쪽 버튼 누르면 score 1씩 증가
        scoreText.innerHTML = score;
    }
    else if(keyCode == 38) {
        moveUp();
        score += 1
        // 키보드 왼쪽 버튼 누르면 score 1씩 증가
        scoreText.innerHTML = score;
    }
    else if(keyCode == 39) {
        moveRight();
        score += 1
        // 키보드 왼쪽 버튼 누르면 score 1씩 증가
        scoreText.innerHTML = score;
    }
    else if(keyCode == 40) {
        moveDown();
        score += 1
        // 키보드 왼쪽 버튼 누르면 score 1씩 증가
        scoreText.innerHTML = score;
    }
    setScore();
});

startGameBtn.addEventListener('click', () => {
    modalEl.style.display = 'none'
    // 게임 스타트 버튼 누르면 게임 스타트 버튼 삭제
    // 그리고 이것은 게임 오버의 버튼을 겸해 같이 사용된다.
})

Restart.addEventListener('click', () => {
    window.location.reload();
    // 리스타트 누르면 다시 시작할수있음.
})

