const Num = document.querySelectorAll(`.Num`); // Num 넘겨받는다
const startGameBtn = document.querySelector('#startGameBtn'); //게임스타트버튼
const Restart = document.querySelector('#Restart');
let NumLength = Num.length; // Num의 길이말하는것
let board=new Array(6);
const scoreText = document.querySelector('#score'); // 스코어 처리해줄떄 필요한 것

let score = 0; // 스코어 초기화

let overCheck = 1;
let numCheck = 1;

for(let i=0;i<6;i++){
    board[i]=new Array(6);
}

for(let i = 0; i < 6; i++) {
    for(let j = 0; j < 6; j++) {
        if(i == 0 || j == 0 || i == 5 || j == 5) {
            board[i][j] = 1;
        }
    }
}

console.log(board);
init();

// GAME START 시작 지정 함수
function init() {
    for(let i = 1; i < 5; i++) { // i가 1 이기 떄문에 1 , 2 , 3 , 4로 짜야해서 5를넣어야한다.
        for(let j = 1; j < 5; j++) { // i가 1 이기 떄문에 1 , 2 , 3 , 4로 짜야해서 5를넣어야한다.
            board[i][j] = 0;
        }
    }
    randomNum();
    randomNum2();
    update();
}


// 업데이트, 여기서 바꿔줌.
function update() {  
    let cnt = 0;
    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            Num[cnt].innerHTML = board[i][j] == 0 ? "" : board[i][j];
            coloring(cnt);
            cnt++;
        }
    }
}

// 스코어 해주는것
function setScore() {
    scoreText.innerHTML = "MoveCount : " + score;
}


// 색변경
function coloring(cnt) { 
    Num[cnt].style.border = "solid black 1px";
    switch(Num[cnt].innerHTML) {
        case "2":
            Num[cnt].style.backgroundColor = "#BFBFFF";
            break;
        case "4":
            Num[cnt].style.backgroundColor = "#9999CC";
            break;
        case "8":
            Num[cnt].style.backgroundColor = "#737399";
            break;    
        case "16":
            Num[cnt].style.backgroundColor = "#8080FF";
            break;
        case "32":
            Num[cnt].style.backgroundColor = "#6666CC";
            break;
        case "64":
            Num[cnt].style.backgroundColor = "#4D4C99";
            break;
        case "128":
            Num[cnt].style.backgroundColor = "#4040FF";
            break;
        case "256":
            Num[cnt].style.backgroundColor = "#3333CC";
            break;
        case "512":
            Num[cnt].style.backgroundColor = "#262699";
            break;
        case "1024":
            Num[cnt].style.backgroundColor = "#0000FF";
            break;
        case "2048":
            Num[cnt].style.backgroundColor = "#000099";
            break;
        default:
            if(Num.innerHTML > 2048) {
                Num[cnt].style.backgroundColor = "#7d5fff";
            }
            else {
                Num[cnt].style.backgroundColor = "#808e9b";
            }    
    }
}
// 랜덤한곳에 넣어줄려고
function randomNum() {
    ranPlaceX = Math.floor(Math.random() * 4 + 1);
    ranPlaceY = Math.floor(Math.random() * 4 + 1);
    if(board[ranPlaceX][ranPlaceY] == 0) {
        board[ranPlaceX][ranPlaceY] = 2;
    }
    else {
        randomNum();
    }
    update();
}
function randomNum2() {
    ranPlaceX = Math.floor(Math.random() * 4 + 1);
    ranPlaceY = Math.floor(Math.random() * 4 + 1);
    if(board[ranPlaceX][ranPlaceY] == 0) {
        board[ranPlaceX][ranPlaceY] = 4;
    }
    else {
        randomNum();
    }
}
// 왼쪽으로 이동했을떄 숫자 계산
function moveLeftNum() {
    let k;

    numCheck = 1

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            if(board[i][j] != 0) {
                k = j;
                while(1) {
                    if(board[i][k-1] != 0) {
                        break;
                    }
                    board[i][k-1] = board[i][k];
                    board[i][k] = 0;
                    k--;
                    numCheck = 0;
                }
            }
        }
    }
}
// 왼쪽으로 이동했을 때
function moveLeft() {
    gameOver();
    moveLeftNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[i][j] == board[i][j+1] && board[i][j] != 0) {
                numCheck = 0;
                board[i][j] *= 2;
                board[i][j+1] = 0;
            }
        }
    }
    if(!numCheck) {
        moveLeftNum();
        randomNum();
        update();
    }
}
// 위쪽으로 이동했을 때 숫자 계산
function moveUpNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            if(board[j][i] != 0) {
                k = j;
                while(1) {
                    if(board[k-1][i] != 0) {
                        break;
                    }
                    board[k-1][i] = board[k][i];
                    board[k][i] = 0;
                    k--;
                    numCheck = 0;
                }
            }
        }
    }
}
// 위쪽으로 이동했을 때
function moveUp() {
    gameOver();
    moveUpNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[j][i] == board[j+1][i] && board[j][i] != 0) {
                board[j][i] *= 2;
                board[j+1][i] = 0;
                numCheck = 0;
            }
        }
    }
    if(!numCheck) {
        moveUpNum();
        randomNum();
        update();
    }
}
// 오른쪽으로 이동했을 때 숫자 계산
function moveRightNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 0; j--) {
            if(board[i][j] != 0) {
                k = j;
                while(1) {
                    if(board[i][k+1] != 0) {
                        break;
                    }
                    board[i][k+1] = board[i][k];
                    board[i][k] = 0;
                    k++;
                    numCheck = 0;
                }
            }
        }
    }
}
// 오른쪽으로 이동했을 때
function moveRight() {
    gameOver();
    moveRightNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j >1; j--) {
            if(board[i][j] == board[i][j-1] && board[i][j] != 0) {
                board[i][j] *= 2;
                board[i][j-1] = 0;
                numCheck = 0;
            }
        }
    }
    if(!numCheck) {
        moveRightNum();
        randomNum();
        update();
    }
}
// 아래쪽으로 이동했을 때 숫자 계산
function moveDownNum() {
    let k;

    numCheck = 1;

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 0; j--) {
            if(board[j][i] != 0) {
                k = j;
                while(1) {
                    if(board[k+1][i] != 0) {
                        break;
                    }
                    board[k+1][i] = board[k][i];
                    board[k][i] = 0;
                    k++; 
                    numCheck = 0;
                }
            }
        }
    }
}
// 아래쪽으로 이동했을 때
function moveDown(){
    gameOver();
    moveDownNum();

    for(let i = 1; i < 5; i++) {
        for(let j = 4; j > 1; j--) {
            if(board[j][i] == board[j-1][i] && board[j][i] != 0) {
                board[j][i] *= 2;
                board[j-1][i] = 0;
                numCheck = 0;
            }
        }
    }
    if(!numCheck) {     
        moveDownNum();
        randomNum();
        update();
    }
}

function rowCheck() {
    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[i][j] == board[i][j+1]) {
                overCheck = 0;
            }
        }
    }
}

function columnCheck() { 
    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 4; j++) {
            if(board[j][i] == board[j+1][i]) {
                overCheck = 0;
            }
        }
    }
}

//게임끝나는것
function gameOver() {
    let fullCheck = 1; // 모든 곳에 다 숫자가 가득찰때

    for(let i = 1; i < 5; i++) {
        for(let j = 1; j < 5; j++) {
            if(board[i][j] == 0) {
                fullCheck = 0; // 초기화
            }
        }
    }
    rowCheck();
    columnCheck();
    if(fullCheck && overCheck) {
        window.location.reload();
    }

    overCheck = 1;
}

//방향키 먹여주는것
window.addEventListener("keydown", (e)=> {
    const keyCode = e.keyCode;
    if(keyCode == 37) {
        moveLeft();
        score += 1
        scoreText.innerHTML = score;
    }
    else if(keyCode == 38) {
        moveUp();
        score += 1
        scoreText.innerHTML = score;
    }
    else if(keyCode == 39) {
        moveRight();
        score += 1
        scoreText.innerHTML = score;
    }
    else if(keyCode == 40) {
        moveDown();
        score += 1
        scoreText.innerHTML = score;
    }
    setScore();
});

startGameBtn.addEventListener('click', () => {
    modalEl.style.display = 'none'
})

Restart.addEventListener('click', () => {
    window.location.reload();
})

