function keyArrowRight(){
    console.log("ArrowRight");
    let blocks = document.getElementsByClassName("blockPrefab");
    for (let i = 0; i < blocks.length; i++){
        
            blocks[i].style.left = 470+"px";   
            
    }
}

function keyArrowLeft(){
    console.log("ArrowLeft");
    let blocks = document.getElementsByClassName("blockPrefab");
    for (let i = 0; i < blocks.length; i++){
        
            blocks[i].style.left =20+"px";        
    }
}
function keyArrowUp(){
    console.log("ArrowUp");
    let blocks = document.getElementsByClassName("blockPrefab");
    for (let i = 0; i < blocks.length; i++){
        blocks[i].style.top = 20+"px";        
    }
}
function keyArrowDown(){
    console.log("ArrowDown");
    let blocks = document.getElementsByClassName("blockPrefab");
    for (let i = 0; i < blocks.length; i++){
        blocks[i].style.top = 470+"px";        
    }
}

function keylog(e){
    console.log(e.key);
    switch(e.key){
        case 'ArrowRight':
            keyArrowRight();
            break;
        case 'ArrowLeft':
            keyArrowLeft();
            break;
        case 'ArrowUp':
            keyArrowUp();
            break;
        case 'ArrowDown':
            keyArrowDown();
            break;
        default:
            break;
    }
}

function keylog(e){
    console.log(e);
}

//window.onkeydown = keylog;
window.onkeydown = (e)=>{console.log(e);};